# API Contracts (Mobile)

## WebView Bridge: RN <-> Three Scene
- postMessage(JSON):
  - { type: 'INIT', config: Partial<Config> }
  - { type: 'SET_CAMERA', payload: { orbit?: [number,number], zoom?: number } }
  - { type: 'SET_LIGHTING', payload: { preset: string } }
  - { type: 'SET_PARTICLES', payload: { density: number } }
  - { type: 'SET_PRESET', payload: { name: string } }
  - { type: 'SNAPSHOT_REQUEST' }
- onMessage(JSON from scene):
  - { type: 'READY' }
  - { type: 'SNAPSHOT_RESULT', dataUri: 'data:image/png;base64,...' }

## PrimefusionEngine
- runPass(config: PassConfig): Promise<PassResult>
- score(result: PassResult): number
- iterate(n: number, profile: 'eco'|'standard'|'burst'): Promise<BestResult>

## Campaigns
- oneTap(theme: string): Promise<CampaignPackage>
- exportPackage(pkg: CampaignPackage): Promise<ExportResult>
