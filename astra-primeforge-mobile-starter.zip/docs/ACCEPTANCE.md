# Acceptance Criteria — Astra Primeforge OS (Mobile v3.0m2)

## 1. Config Load
- Loads /src/config/astra_mobile.json at app start
- Exposes config via Zustand store
- Fallback defaults if missing keys

## 2. UI & Gestures
- Mini‑nav switches panels (Scenes, Avatars, Modes, Tools)
- Bottom bar buttons trigger handlers (camera, lighting, effects, avatars, voice, render)
- Gestures: orbit (drag), zoom (pinch), pan (two‑finger), avatar expand (tap‑hold), director mode (two‑finger tap)
- Haptics fire on key actions

## 3. Scene Viewport
- WebView renders a local Three.js scene (scene.html)
- Bridge message handlers: setCamera, setLighting, setParticles, setPreset(name), snapshot()
- Auto‑fit on pinch‑release

## 4. Primefusion (Mobile)
- UI presents passes/profile (eco/standard/burst)
- Async iteration loop runs N passes with status updates
- Self‑critique stub calculates a mock “aesthetic_score”
- Best-of selection returns final preview and stores Variation IDs

## 5. Avatars (Echo/Nova)
- Toggle avatars on/off; expand to full body
- Micro‑emotion state changes (UI/animation placeholders)
- Voice: play narrator/host sample lines via expo-av

## 6. One‑Tap Campaign Generator
- Triggers generation of (mock) assets per config counts
- Produces share sheet payloads and saves assets to file-system
- Fires webhook event “campaign_ready” (log stub)

## 7. Storage & Export
- Projects save locally; versioning keeps last 10
- Export MP4/PNG/WebP via stub (simulate save files and metadata)
- Social share opens native share dialog

## 8. Integrations
- Shopify/Supliful stubs accept API keys (env) and mock sync
- Suno prompt template builder returns structured payloads

## 9. Accessibility & Perf
- High contrast and reduce motion toggles adjust theme
- Thermal guard downshifts profiles on device warm

All criteria must be demo‑able on device via Expo Go.
