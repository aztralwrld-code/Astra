export async function oneTap(theme:string){
  // TODO: generate assets (mock files) and return package
  return { theme, items:[
    {type:'tiktok', file:'tiktok_01.mp4'},
    {type:'image', file:'image_01.png'}
  ]};
}