export type ScenePreset = 'temple_mini'|'neon_lab_compact'|'void_pocket_scene';
export function applyPreset(webview:any, name:ScenePreset){
  // TODO: send bridge message to set preset once implemented in scene.html
  webview?.postMessage(JSON.stringify({type:'SET_PRESET', payload:{name}}));
}