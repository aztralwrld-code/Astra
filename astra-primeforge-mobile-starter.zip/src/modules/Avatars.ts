export type AvatarName = 'Echo'|'Nova';
export type Emotion = 'soft'|'host'|'firebrand'|'narrator';
export function setAvatarState(name:AvatarName, emotion:Emotion){
  // TODO: animate UI layers and voice lines per config
}