export type Profile = 'eco'|'standard'|'burst';
export type PassResult = { id:string; score:number; previewDataUri?:string };
export async function runPass(pass: number): Promise<PassResult>{
  // TODO: call into scene to tweak params, render snapshot, compute score
  await new Promise(r=>setTimeout(r, 300));
  const score = Math.random()*0.3 + 0.7; // stub
  return { id: 'pass_'+pass, score };
}
export async function iterate(n:number, profile:Profile='standard'){
  const results: PassResult[] = [];
  for(let i=1;i<=n;i++){ results.push(await runPass(i)); }
  results.sort((a,b)=> b.score - a.score);
  return { best: results[0], all: results };
}