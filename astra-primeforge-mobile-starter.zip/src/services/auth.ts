export const Auth = {
  async signInAnonymously(){ /* TODO */ },
  async signInWithApple(){ /* TODO */ }
}