export const Storage = {
  async saveProject(p:any){ /* TODO */ },
  async loadProjects(){ return [] as any[]; }
}