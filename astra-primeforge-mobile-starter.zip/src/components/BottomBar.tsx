import { View, Text, TouchableOpacity } from 'react-native';
const buttons = ['camera','lighting','effects','avatars','voice','render','export'];
export function BottomBar(){
  return <View style={{flexDirection:'row', justifyContent:'space-around', padding:10, backgroundColor:'#120a25'}}>
    {buttons.map(b=> <TouchableOpacity key={b}><Text style={{color:'#F5D06F'}}>{b}</Text></TouchableOpacity>)}
  </View>
}