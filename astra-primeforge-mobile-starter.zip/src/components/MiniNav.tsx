import { View, Text, TouchableOpacity } from 'react-native';
export function MiniNav(){
  const items = ['projects','scenes','avatars','modes','tools'];
  return <View style={{flexDirection:'row', padding:12, gap:8}}>
    {items.map(i=> <TouchableOpacity key={i} style={{padding:8, borderRadius:10, backgroundColor:'#1b1333'}}><Text style={{color:'#C8A2FF'}}>{i}</Text></TouchableOpacity>)}
  </View>
}