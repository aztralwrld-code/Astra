import { useEffect, useRef } from 'react';
import { WebView } from 'react-native-webview';
import { Asset } from 'expo-asset';
import * as FileSystem from 'expo-file-system';
import { View } from 'react-native';

export function SceneViewport(){
  const ref = useRef<WebView>(null);
  useEffect(()=>{ /* TODO: wire gestures and config-driven presets */ }, []);

  const onMessage = (e:any)=>{
    try{ const msg = JSON.parse(e.nativeEvent.data); console.log('[SCENE]', msg); }
    catch{}
  };

  return <View style={{flex:1, borderTopWidth:1, borderColor:'#1b1333'}}>
    <WebView ref={ref} originWhitelist={['*']} onMessage={onMessage}
      source={require('../scene/scene.html')} allowFileAccess 
      javaScriptEnabled domStorageEnabled />
  </View>;
}