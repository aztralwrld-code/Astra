import { create } from 'zustand';
import configJson from '../config/astra_mobile.json';
type State = { config: any, currentPreset?: string };
export const useAstra = create<State>(()=>({
  config: configJson,
  currentPreset: undefined
}));