import { View, Text } from 'react-native';
import { SceneViewport } from '../../src/components/SceneViewport';
import { BottomBar } from '../../src/components/BottomBar';
import { MiniNav } from '../../src/components/MiniNav';
export default function Home(){
  return <View style={{flex:1, backgroundColor:'#0F0A1F'}}>
    <MiniNav />
    <SceneViewport />
    <BottomBar />
  </View>
}