# Astra Primeforge OS — Mobile (v3.0m2)

A **mobile-only** creative OS scaffold for Astra: Primefusion AEI, Quantum Scene Forge, Echo/Nova avatars,
One‑Tap Campaigns, touch-first UI. This repo is a *starter kit* you can hand to a Coding GPT to fully implement.

---

## Tech Stack (recommended)
- **Expo + React Native + TypeScript**
- **expo-router** for file-based navigation
- **Zustand** for state
- **react-native-reanimated** + **gesture-handler** for gestures
- **react-native-webview** (Three.js scene via webview bridge) or **expo-three** for GL previews
- **expo-av** (sound design), **expo-haptics** (haptics), **expo-file-system** (storage)
- **expo-secure-store** for auth tokens
- **Shopify & Supliful** stubs included (wire real creds later)

---

## Project Goals
- Load **/src/config/astra_mobile.json** and expose it as runtime config
- Implement **gestures**: orbit, zoom, pan, avatar expand, director mode tap
- Ship **One‑Tap Campaign Generator** producing assets & share flows
- Implement **Echo/Nova** avatar micro‑emotion states (UI + hooks)
- Implement **Primefusion (mobile)** iteration loop (UI + stub engine with async steps)
- Scene rendering via **WebView** bridge → **Three.js** minimal scene, then upscale preview
- Local caches + cloud sync (stubs included)
- Export MP4/PNG/WebP (RN-FFmpeg or native modules — stub here; Coding GPT fills in)

---

## How to Use With a Coding GPT
Paste the following instruction to the Coding GPT working on this repo:

> You are my implementation agent. Open the provided project. Install dependencies from package.json. Fill all TODOs in src/modules/* and src/components/*. Implement the WebView <-> React Native bridge for scene controls in src/components/SceneViewport.tsx and src/modules/QuantumSceneForge.ts. Implement Primefusion iteration flow in src/modules/PrimefusionEngine.ts. Wire One‑Tap Campaign Generator in src/modules/Campaigns.ts. Ensure all commands and gestures match src/config/astra_mobile.json. Produce a Test Plan that passes the acceptance criteria in /docs/ACCEPTANCE.md. Keep TypeScript strict.

---

## Quick Start
```bash
# with Node 20+
npm i -g expo
npm install
npx expo start
```

Run on iOS device via Expo Go, then sign in to unlock camera/mic permissions.

---

## Structure
- **app/**: screens & routing
- **src/components/**: UI building blocks
- **src/modules/**: engines, features (Primefusion, Quantum, Avatars, Campaigns)
- **src/services/**: auth, storage, analytics, integrations
- **src/state/**: global store (Zustand)
- **src/config/**: mobile JSON config
- **docs/**: acceptance criteria & API contracts

---

## Notes
- This is a scaffold. Coding GPT should replace the stubs with working code.
- For heavier rendering, consider offloading final renders to a server and keep mobile as a director client.
- The Three.js demo scene is minimal; expand materials/lighting as needed.

